var searchData=
[
  ['square_0',['Square',['../class_square.html',1,'']]],
  ['symulacja_1',['Symulacja',['../class_symulacja.html',1,'']]]
];
