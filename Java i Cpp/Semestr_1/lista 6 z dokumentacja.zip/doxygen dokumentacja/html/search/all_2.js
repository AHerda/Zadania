var searchData=
[
  ['square_0',['Square',['../class_square.html',1,'']]],
  ['start_1',['start',['../class_symulacja.html#a3a5509557a38e3446429e1236339113a',1,'Symulacja']]],
  ['symulacja_2',['Symulacja',['../class_symulacja.html',1,'']]]
];
