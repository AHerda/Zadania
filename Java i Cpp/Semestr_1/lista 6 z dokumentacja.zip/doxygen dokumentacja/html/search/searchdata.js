var indexSectionsWithContent =
{
  0: "mrs",
  1: "ms",
  2: "mrs"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions"
};

